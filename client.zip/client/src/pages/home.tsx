import { useState } from "react";
import Header from "@/components/header";
import NameInput from "@/components/name-input";
import PhotoUpload from "@/components/photo-upload";
import ViewToggle from "@/components/view-toggle";
import EditMode from "@/components/edit-mode";
import PreviewMode from "@/components/preview-mode";
import LoadModal from "@/components/load-modal";
import { useQuery } from "@tanstack/react-query";
import { type Profile } from "@shared/schema";

export type BiographyData = {
  name: string;
  background: string;
  achievements: string;
  skills: string;
  goals: string;
  photoUrl?: string;
};

export default function Home() {
  const [currentMode, setCurrentMode] = useState<'edit' | 'preview'>('edit');
  const [biographyData, setBiographyData] = useState<BiographyData>({
    name: '',
    background: '',
    achievements: '',
    skills: '',
    goals: '',
    photoUrl: ''
  });
  const [isLoadModalOpen, setIsLoadModalOpen] = useState(false);

  const { data: profiles = [], refetch } = useQuery<Profile[]>({
    queryKey: ['/api/profiles'],
  });

  const updateBiographyData = (updates: Partial<BiographyData>) => {
    setBiographyData(prev => ({ ...prev, ...updates }));
  };

  const generateBiography = (name: string) => {
    const firstName = name.split(' ')[0];
    
    const templates = {
      background: `${firstName} is a dedicated professional with a diverse background in [Your Field]. Born and raised in [Your Location], they developed an early passion for [Your Interest] which guided their academic and career choices. They completed their studies in [Your Degree] at [Your University], where they distinguished themselves through [Notable Academic Achievement]. Their formative years were shaped by [Key Experiences], instilling a strong foundation in [Core Values/Skills].`,
      
      achievements: `Throughout their career, ${firstName} has accomplished several notable milestones including [Major Achievement 1], [Major Achievement 2], and [Major Achievement 3]. Their most significant project was [Project Name], which resulted in [Specific Outcome/Impact]. They have been recognized with [Awards/Recognition] and have successfully led initiatives that [Specific Results]. Their contributions to [Field/Industry] have been acknowledged by [Recognition Source].`,
      
      skills: `${firstName}'s core competencies include [Technical Skills], with particular expertise in [Specialized Area]. They possess strong [Communication/Leadership/Analytical] skills and are known for their [Personal Strengths like problem-solving, creativity, etc.]. Their ability to [Key Ability] has been instrumental in their success. Additional strengths include [Additional Skills], making them a versatile and effective professional in [Work Environment/Context].`,
      
      goals: `Looking toward the future, ${firstName} is focused on [Primary Career Goal] and aspires to [Long-term Vision]. Their immediate objectives include [Short-term Goals], while their broader mission involves [Impact Goal]. They are particularly passionate about [Area of Interest] and plan to [Future Plans]. Through their continued efforts, they aim to [Ultimate Aspiration] and contribute meaningfully to [Field/Community/Society].`
    };

    setBiographyData({
      name,
      ...templates
    });
  };

  const loadProfile = (profile: Profile) => {
    setBiographyData({
      name: profile.name,
      background: profile.background,
      achievements: profile.achievements,
      skills: profile.skills,
      goals: profile.goals,
      photoUrl: profile.photoUrl || ''
    });
    setIsLoadModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        onOpenLoadModal={() => setIsLoadModalOpen(true)}
        biographyData={biographyData}
        onSaveSuccess={() => refetch()}
      />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <NameInput 
          onGenerate={generateBiography}
          initialName={biographyData.name}
        />
        
        <PhotoUpload
          currentPhotoUrl={biographyData.photoUrl}
          onPhotoChange={(photoUrl) => updateBiographyData({ photoUrl })}
        />
        
        <ViewToggle 
          currentMode={currentMode}
          onModeChange={setCurrentMode}
        />

        {currentMode === 'edit' ? (
          <EditMode 
            biographyData={biographyData}
            onUpdate={updateBiographyData}
          />
        ) : (
          <PreviewMode biographyData={biographyData} />
        )}
      </main>

      <LoadModal
        isOpen={isLoadModalOpen}
        onClose={() => setIsLoadModalOpen(false)}
        profiles={profiles}
        onLoadProfile={loadProfile}
      />
    </div>
  );
}
