import { Textarea } from "@/components/ui/textarea";
import { User, Trophy, Wrench, Target } from "lucide-react";
import { type BiographyData } from "@/pages/home";

interface EditModeProps {
  biographyData: BiographyData;
  onUpdate: (updates: Partial<BiographyData>) => void;
}

export default function EditMode({ biographyData, onUpdate }: EditModeProps) {
  const sections = [
    {
      id: 'background',
      title: 'Background & Personal Information',
      icon: User,
      color: 'blue',
      placeholder: 'Describe your educational background, early life, interests, and what shaped your journey. Include details about your studies, formative experiences, and personal interests that define who you are today.',
      value: biographyData.background
    },
    {
      id: 'achievements',
      title: 'Main Achievements & Projects',
      icon: Trophy,
      color: 'green',
      placeholder: 'Highlight your most significant accomplishments, successful projects, awards, recognitions, and milestones in your career or personal life. Include specific examples and measurable outcomes where possible.',
      value: biographyData.achievements
    },
    {
      id: 'skills',
      title: 'Skills & Strengths',
      icon: Wrench,
      color: 'purple',
      placeholder: 'List your core competencies, technical skills, soft skills, and personal strengths. Include both professional abilities and character traits that make you unique and effective in your endeavors.',
      value: biographyData.skills
    },
    {
      id: 'goals',
      title: 'Goals & Future Plans',
      icon: Target,
      color: 'orange',
      placeholder: 'Outline your aspirations, future objectives, career goals, and vision for what you want to achieve. Include both short-term and long-term plans, as well as the impact you hope to make.',
      value: biographyData.goals
    }
  ];

  const getIconBgColor = (color: string) => {
    switch (color) {
      case 'blue': return 'bg-blue-100';
      case 'green': return 'bg-green-100';
      case 'purple': return 'bg-purple-100';
      case 'orange': return 'bg-orange-100';
      default: return 'bg-blue-100';
    }
  };

  const getIconColor = (color: string) => {
    switch (color) {
      case 'blue': return 'text-blue-600';
      case 'green': return 'text-green-600';
      case 'purple': return 'text-purple-600';
      case 'orange': return 'text-orange-600';
      default: return 'text-blue-600';
    }
  };

  return (
    <div className="space-y-6" data-testid="edit-mode">
      {sections.map((section) => (
        <div key={section.id} className="bg-card rounded-lg border border-border p-6 shadow-sm">
          <div className="flex items-center space-x-3 mb-4">
            <div className={`w-8 h-8 ${getIconBgColor(section.color)} rounded-md flex items-center justify-center`}>
              <section.icon className={`${getIconColor(section.color)} h-4 w-4`} />
            </div>
            <h3 className="text-lg font-semibold text-foreground">{section.title}</h3>
          </div>
          <Textarea
            rows={4}
            placeholder={section.placeholder}
            value={section.value}
            onChange={(e) => onUpdate({ [section.id]: e.target.value })}
            className="resize-none"
            data-testid={`textarea-${section.id}`}
          />
        </div>
      ))}
    </div>
  );
}
