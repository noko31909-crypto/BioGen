import { Save, FolderOpen, UserCog } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type BiographyData } from "@/pages/home";

interface HeaderProps {
  onOpenLoadModal: () => void;
  biographyData: BiographyData;
  onSaveSuccess: () => void;
}

export default function Header({ onOpenLoadModal, biographyData, onSaveSuccess }: HeaderProps) {
  const { toast } = useToast();

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!biographyData.name.trim()) {
        throw new Error('Please enter a name before saving.');
      }
      
      const response = await apiRequest('POST', '/api/profiles', {
        name: biographyData.name,
        background: biographyData.background,
        achievements: biographyData.achievements,
        skills: biographyData.skills,
        goals: biographyData.goals,
        photoUrl: biographyData.photoUrl
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Profile saved successfully!",
      });
      onSaveSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
              <UserCog className="text-primary-foreground h-4 w-4" />
            </div>
            <h1 className="text-xl font-semibold text-foreground">Personal Biographer</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onOpenLoadModal}
              data-testid="button-load-profile"
            >
              <FolderOpen className="h-4 w-4 mr-2" />
              Load Profile
            </Button>
            <Button 
              size="sm"
              onClick={() => saveMutation.mutate()}
              disabled={saveMutation.isPending}
              data-testid="button-save-profile"
            >
              <Save className="h-4 w-4 mr-2" />
              {saveMutation.isPending ? 'Saving...' : 'Save Profile'}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
