import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Wand2 } from "lucide-react";

interface NameInputProps {
  onGenerate: (name: string) => void;
  initialName: string;
}

export default function NameInput({ onGenerate, initialName }: NameInputProps) {
  const [name, setName] = useState(initialName);

  const handleGenerate = () => {
    const trimmedName = name.trim();
    if (!trimmedName) {
      alert('Please enter a name to generate a biography.');
      return;
    }
    onGenerate(trimmedName);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6 mb-8 shadow-sm">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-semibold text-foreground mb-2">Create Your Professional Biography</h2>
        <p className="text-muted-foreground">Generate a comprehensive biographical profile with structured sections for background, achievements, skills, and goals.</p>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
        <Input
          type="text"
          placeholder="Enter your full name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="flex-1"
          data-testid="input-name"
        />
        <Button 
          onClick={handleGenerate}
          className="px-6"
          data-testid="button-generate-biography"
        >
          <Wand2 className="h-4 w-4 mr-2" />
          Generate Biography
        </Button>
      </div>
    </div>
  );
}
